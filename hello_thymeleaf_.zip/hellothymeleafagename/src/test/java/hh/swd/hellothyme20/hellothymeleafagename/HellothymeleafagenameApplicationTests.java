package hh.swd.hellothyme20.hellothymeleafagename;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellothymeleafagenameApplicationTests {

	@Test
	void contextLoads() {
	}

}
